import React from 'react';
import { Instagram, Linkedin, Mail } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-2xl font-bold text-purple-400 mb-4">SAV WOMAN</h3>
            <p className="text-gray-300 mb-4">
              Empowering young women to echo brilliance through community, 
              mentorship, and growth opportunities.
            </p>
            <div className="flex space-x-4">
              <Instagram className="h-6 w-6 text-gray-300 hover:text-purple-400 cursor-pointer" />
              <Linkedin className="h-6 w-6 text-gray-300 hover:text-purple-400 cursor-pointer" />
              <Mail className="h-6 w-6 text-gray-300 hover:text-purple-400 cursor-pointer" />
            </div>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Programs</h4>
            <ul className="space-y-2 text-gray-300">
              <li><a href="#" className="hover:text-purple-400">Mentorship</a></li>
              <li><a href="#" className="hover:text-purple-400">Leadership</a></li>
              <li><a href="#" className="hover:text-purple-400">Workshops</a></li>
              <li><a href="#" className="hover:text-purple-400">Scholarships</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Community</h4>
            <ul className="space-y-2 text-gray-300">
              <li><a href="#" className="hover:text-purple-400">Join Us</a></li>
              <li><a href="#" className="hover:text-purple-400">Events</a></li>
              <li><a href="#" className="hover:text-purple-400">Blog</a></li>
              <li><a href="#" className="hover:text-purple-400">Alumni</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Support</h4>
            <ul className="space-y-2 text-gray-300">
              <li><a href="#" className="hover:text-purple-400">Contact</a></li>
              <li><a href="#" className="hover:text-purple-400">FAQ</a></li>
              <li><a href="#" className="hover:text-purple-400">Resources</a></li>
              <li><a href="#" className="hover:text-purple-400">Volunteer</a></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
          <p>&copy; 2024 SAV WOMAN. All rights reserved. Empowering women, transforming communities.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
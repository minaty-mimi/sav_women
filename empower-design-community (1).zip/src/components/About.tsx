import React from 'react';
import { Button } from '@/components/ui/button';

const About: React.FC = () => {
  return (
    <section className="py-20 bg-purple-50" id="about">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <img 
              src="/placeholder.svg" 
              alt="SAV WOMAN Mission"
              className="rounded-lg shadow-lg w-full h-96 object-cover"
            />
          </div>
          <div>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              About SAV WOMAN
            </h2>
            <p className="text-lg text-gray-700 mb-6 leading-relaxed">
              SAV WOMAN was founded with a simple yet powerful mission: to create a world where 
              every young woman has the confidence, resources, and community support needed to 
              achieve her dreams and make a lasting impact.
            </p>
            <p className="text-lg text-gray-700 mb-6 leading-relaxed">
              We believe that when women are empowered, entire communities thrive. Through our 
              comprehensive programs, mentorship opportunities, and vibrant community network, 
              we're building the next generation of confident, capable leaders.
            </p>
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-purple-600 rounded-full"></div>
                <span className="text-gray-700">Over 1,000 young women empowered</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-purple-600 rounded-full"></div>
                <span className="text-gray-700">50+ mentors and role models</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-purple-600 rounded-full"></div>
                <span className="text-gray-700">100+ workshops and events annually</span>
              </div>
            </div>
            <div className="mt-8">
              <Button size="lg" className="bg-purple-600 hover:bg-purple-700">
                Learn More About Our Mission
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
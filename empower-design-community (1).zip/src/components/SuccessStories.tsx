import React from 'react';
import { Card, CardContent } from '@/components/ui/card';

const SuccessStories: React.FC = () => {
  const stories = [
    {
      name: 'Amara Johnson',
      role: 'College Student & Entrepreneur',
      quote: 'SAV WOMAN gave me the confidence to start my own business at 19. The mentorship and community support have been life-changing.',
      image: '/placeholder.svg'
    },
    {
      name: 'Zara Okafor',
      role: 'Tech Professional',
      quote: 'Through SAV WOMAN, I found my passion for technology and now work at a leading tech company. The network is incredible.',
      image: '/placeholder.svg'
    },
    {
      name: 'Maya Patel',
      role: 'Community Leader',
      quote: 'The leadership skills I developed through SAV WOMAN helped me become a voice for change in my community.',
      image: '/placeholder.svg'
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Success Stories
          </h2>
          <p className="text-xl text-gray-600">
            Hear from the incredible women who have grown through our community
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {stories.map((story, index) => (
            <Card key={index} className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6 text-center">
                <img 
                  src={story.image} 
                  alt={story.name}
                  className="w-20 h-20 rounded-full mx-auto mb-4 object-cover"
                />
                <blockquote className="text-gray-700 mb-4 italic">
                  "{story.quote}"
                </blockquote>
                <div>
                  <h4 className="font-semibold text-gray-900">{story.name}</h4>
                  <p className="text-purple-600 text-sm">{story.role}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SuccessStories;